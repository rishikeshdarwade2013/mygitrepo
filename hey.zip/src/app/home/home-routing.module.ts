import { AdminModule } from 'src/app/admin/admin.module';
import { LoginComponent } from 'src/app/home/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeIndexComponent } from "src/app/home/home-index/home-index.component";

import { LoginAuthenticationGuard } from "src/app/home/shared/login-authentication.guard";
import { SignUpComponent } from "src/app/home/sign-up/sign-up.component";
import { ProfileComponent } from "src/app/home/profile/profile.component";
import { SearchBarComponent } from "src/app/home/search-bar/search-bar.component";
import { ChangeotpComponent } from "src/app/home/login/changeotp/changeotp.component";
import { ChangePasswordComponent } from "src/app/home/profile/change-password/change-password.component";
import { EditUserComponent } from "src/app/home/profile/edit-user/edit-user.component";


const routes: Routes = [
  { path: '', component: HomeIndexComponent },
  { path: 'Login', component: LoginComponent },
  { path: 'changeotp', component: ChangeotpComponent },
  { path: 'signup', component: SignUpComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'propsearch', component: SearchBarComponent },
  {path : 'changepassword', component : ChangePasswordComponent},
  {path : 'editprofile', component : EditUserComponent}
];
// 
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
