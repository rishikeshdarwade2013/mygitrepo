import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import { PropertyService } from "src/app/home/Property-shared/property.service";
import { City } from "src/app/home/User-shared/Property.Model";
import { startWith, map } from "rxjs/operators";

@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.css']
})
export class SearchBarComponent implements OnInit {

  constructor(private router: Router,public propertyservice:PropertyService) { }
  myControl = new FormControl();
  options = new Array<string>();
  filteredOptions: Observable<string[]>;

  ngOnInit() {
    this.propertyservice.getCityList().subscribe(data => {
      this.propertyservice.options = data as City[];
      this.propertyservice.options.forEach(element => {
        this.options.push(element.City_name);
      });
      
      this.filteredOptions = this.myControl.valueChanges
        .pipe(
        startWith(''),
        map(value => this._filter(value))
        );   
    })
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

 onDone(valuei: string) {
    this.router.navigate(['/property-lists', {valuei}]);
  }

}
