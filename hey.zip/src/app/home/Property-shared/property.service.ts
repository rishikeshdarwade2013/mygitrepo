import { Injectable } from '@angular/core';
import { Property, City } from "src/app/home/User-shared/Property.Model";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class PropertyService {

  Selectedproperty = new Property();
  options = new Array<City>();
  Place :string;
  CityNames = new Array<string>();
  PropertyList= new Array<Property>();
  Pid:number;
  constructor(private http: HttpClient) { }

  getCityList() : Observable<any>{
     
    return this.http.get('http://localhost:59207/api/PropertyDetails/GetCity');
  }

  getPropertyList(city:string) :Observable<any>
  {
    return this.http.get('http://localhost:59207/api/PropertyDetails/GetProperties?city='+city);
  }
  getProperties(id: number): Observable<any> {
    return this.http.get('http://localhost:59207/api/PropertyDetails/GetProperty?id='+ id);
  }

}
