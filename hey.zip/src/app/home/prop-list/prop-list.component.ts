import { Component, OnInit } from '@angular/core';
import { UserProfileService } from "src/app/home/User-shared/user-profile.service";
import { PropertyService } from "src/app/home/Property-shared/property.service";

@Component({
  selector: 'app-prop-list',
  templateUrl: './prop-list.component.html',
  styleUrls: ['./prop-list.component.css']
})
export class PropListComponent implements OnInit {

  constructor(public propertyService : PropertyService) { }

  ngOnInit() {
  }

}
