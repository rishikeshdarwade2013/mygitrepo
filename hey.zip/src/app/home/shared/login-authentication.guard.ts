import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginAuthenticationService } from 'src/app/home/shared/login-authentication.service';

@Injectable({
  providedIn: 'root'
})
export class LoginAuthenticationGuard implements CanActivate {
  constructor(private authServ: LoginAuthenticationService, private router: Router)
  {}
  canActivate():boolean{
    if(this.authServ.loggedIn())
      {return true;
      }
      else
      {
        this.router.navigate(['/home/Login']);
        return false;
      }
  }

}
