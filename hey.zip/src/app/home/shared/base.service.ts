import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { from } from 'rxjs';
import {map} from 'rxjs/operators';
import {HttpModule,Http,Response,Headers,RequestOptions,RequestMethod} from '@angular/http';
import { BoolData } from "src/app/home/shared/BoolData.model";
import { Router } from "@angular/router";
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class BaseService {
  boolDataObj:BoolData;
  isValid:Boolean;
  userName:string;
  userID:number;
  userEmailID:string;
  constructor(private http:Http,private router:Router)
  {}
  validateUser(str:string)
  { 
  return this.http.get('http://localhost:59207/api/Users/LoginCheck?id='+encodeURIComponent(str)).pipe(map((data:Response)=>{
    return data.json() as BoolData;
   })).toPromise().then(x=>{
     this.boolDataObj=x;
  
     if(this.boolDataObj.isValid)
      {
        this.userName=this.boolDataObj.userName;
        this.userID=this.boolDataObj.userID;
        this.fixUsertoken();
        this.router.navigateByUrl('/home');
      }
     else 
      {
        this.router.navigate(['Login'])
      }})
 }
 fixUsertoken()
 {
     localStorage.setItem('userToken',this.boolDataObj.tokenString);
     console.log(this.boolDataObj.tokenString);
 }
}
   
  
  