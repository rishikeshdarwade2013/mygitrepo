import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginAuthenticationService {

  constructor(private base:BaseService,private http:Http,private router:Router) { }
  adminloggedIn()
  {
    if(localStorage.getItem('adminToken')!=null)
      return true;
    else
      return false;
  }
  loggedIn()
  {
    if(localStorage.getItem('userToken')!=null)
      return true;
    else
      return false;
  }
  getToken()
  {
    return localStorage.getItem('userToken')
  }
  logoutUser()
  {
    this.base.userEmailID=null;
    this.base.userID=null;
    localStorage.removeItem('userToken')
    this.router.navigate(['Home'])
  }
}
