export class BoolData {
    isValid:Boolean;
    tokenString:string;
    userName:string;
    userID:number;
    
   }