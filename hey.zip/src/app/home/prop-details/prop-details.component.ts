import { Component, OnInit } from '@angular/core';
import { Property } from "src/app/home/User-shared/Property.Model";
import { PropertyService } from "src/app/home/Property-shared/property.service";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-prop-details',
  templateUrl: './prop-details.component.html',
  styleUrls: ['./prop-details.component.css']
})
export class PropDetailsComponent implements OnInit {

  property = new Property();
  constructor(public propertyservice: PropertyService, private route: ActivatedRoute) { }

  ngOnInit(): void {
  this.route.params.subscribe(params => { this.propertyservice.Pid= params['val'] });
  this.propertyservice.getProperties(this.propertyservice.Pid).subscribe(data => {
    this.propertyservice.Selectedproperty = data as Property
  });
  }

}
