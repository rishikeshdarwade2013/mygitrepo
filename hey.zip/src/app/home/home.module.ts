
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeIndexComponent } from './home-index/home-index.component';
import { HomeRoutingModule } from "./home-routing.module";
import { LoginComponent } from 'src/app/home/login/login.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ProfileComponent } from './profile/profile.component';
import { PropListComponent } from './prop-list/prop-list.component';
import { PropDetailsComponent } from './prop-details/prop-details.component';
import { SearchBarComponent } from './search-bar/search-bar.component';
import { MatAutocompleteModule, MatFormFieldModule, MatInputModule, MatGridListModule, MatCardModule, MatIconModule, MatButtonModule } from "@angular/material";
import {ToastrService, ToastrModule} from "ngx-toastr";
import { ChangePasswordComponent } from './profile/change-password/change-password.component';
import { ChangeotpComponent } from './login/changeotp/changeotp.component';
import { EditUserComponent } from './profile/edit-user/edit-user.component';

@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    ToastrModule.forRoot(),
    MatAutocompleteModule, MatFormFieldModule, MatInputModule, MatGridListModule, MatCardModule, MatIconModule, MatButtonModule,ReactiveFormsModule
  ],
  declarations: [HomeIndexComponent, LoginComponent, SignUpComponent, ProfileComponent, PropListComponent, PropDetailsComponent, SearchBarComponent, ChangePasswordComponent, ChangeotpComponent, EditUserComponent,
  ],
  providers : [ToastrService]
})
export class HomeModule { }
