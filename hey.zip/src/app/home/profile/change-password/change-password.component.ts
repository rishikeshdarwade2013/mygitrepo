import { Component, OnInit } from '@angular/core';
import { PasswordService } from "src/app/home/User-shared/password.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  fieldDisable=true;
  newPasword:string;
  confirmNew:string;
  oldPasword:string;
  buttonDisable=true;
  smallValue1=true;
  smallValue2=true;
  updateResult=true;
  oldField=true;
  result:string;
  constructor(public passwordservice : PasswordService, public router : Router) { }

  ngOnInit() {
  }

  checkPasswords()
  {
    if(this.newPasword==this.confirmNew)
        this.buttonDisable=false;
  }

  confirmChangePassword()
  {
    //this.Password=this.oldPasword+":"+this.newPasword
    this.passwordservice.confirmPassword(this.oldPasword).subscribe(data => {
      this.result = data.toString();
      if(this.result=='1')
        {
          this.fieldDisable=false;
          this.oldField=true;
        }
        
      else
        this.oldField=false;
      
    });
  }

  updatePassword()
  {
    if(this.newPasword==this.confirmNew )
      this.passwordservice.updatePassword(this.newPasword).subscribe(data => {
        this.result = data.toString();
        console.log(data);
        if(this.result=='1')
          this.updateResult=false;
        else
          {
            this.router.navigateByUrl('/bad-request');
          }
      });
    else
      console.log(" no match");
    
  }

}
