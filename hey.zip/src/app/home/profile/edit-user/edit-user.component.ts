import { Component, OnInit } from '@angular/core';
import { User } from "src/app/home/User-shared/UserModel";
import { UserProfileService } from "src/app/home/User-shared/user-profile.service";
import { NgForm } from "@angular/forms";
import { ToastrService } from "ngx-toastr";


@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  user:User;
  result:number;
  constructor(public userService : UserProfileService, private toastr: ToastrService) { }

  ngOnInit() {
    this.userService.getUserById(1).subscribe(data =>
      this.userService.selectedUser=data)
    
  }

  resetForm(form?: NgForm)
  {
    if(form != null)
      {
        form.reset();
        this.userService.selectedUser = new User();
      }
  }

  onSubmit(form : NgForm)
  {
    if(form.value.userId==null)
      {
        console.log(this.userService.selectedUser);
         this.userService.postUser(this.userService.selectedUser)
        .subscribe(data=>{
        this.resetForm(form);
        this.toastr.success('New Record added successfully','User Registration');
      },
      err=>{
        console.log("Error in inserting data");
      }
    )}
    else
    {
      console.log(this.userService.selectedUser.Name);
      this.userService.putUser(this.userService.selectedUser)
      .subscribe(data=>{
        console.log('hello');
      this.resetForm(form);           
      this.toastr.success('Record updated successfully','Employee Register');            
      },
      err=>{
        console.log("Error in inserting data");
      }
    )}
    
  }


}
