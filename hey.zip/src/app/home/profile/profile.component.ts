import { Component, OnInit } from '@angular/core';
import { User } from "src/app/home/User-shared/UserModel";
import { Property } from "src/app/home/User-shared/Property.Model";
import { RouterModule, Router } from "@angular/router";
import { UserProfileService } from "src/app/home/User-shared/user-profile.service";
import { SignupService } from "src/app/home/User-shared/signup.service";

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  user = new User();
  property = new Property();
  uid : number;
  constructor(public userservice:UserProfileService, public router : Router) { }

  ngOnInit() {
    this.userservice.getUserById(1).subscribe( data => {
      this.user = data as User ;
      this.uid = this.user.UserId;
    })

    this.userservice.getUserPropertyById(1).subscribe( data => {
      this.property = data as Property;
    })

    this.userservice.getPropertyList(1).subscribe( data => {
      this.userservice.PropertyList = data 
      console.log(this.userservice.PropertyList)
    })
  }

  Edit() // Edit directly in HTML
  {
      this.router.navigateByUrl('//home/editprofile');
  }

  ChangePassword(){
    this.router.navigateByUrl('/home/changepassword')
  }

}
