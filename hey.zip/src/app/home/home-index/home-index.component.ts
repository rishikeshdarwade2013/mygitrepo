import { BaseService } from './../../home/shared/base.service';
import { LoginAuthenticationService } from 'src/app/home/shared/login-authentication.service';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-home-index',
  templateUrl: './home-index.component.html',
  styleUrls: ['./home-index.component.css']
})
export class HomeIndexComponent implements OnInit {

  constructor(public authService: LoginAuthenticationService,public base:BaseService,private toastr: ToastrService) { }

  ngOnInit() {
  }
  





}
