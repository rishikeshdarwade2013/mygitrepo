export class Property {
    Bachelor_friendly:boolean;
    Built_up_area:number;
    Deal_type:string;
    Flat_type:string;
    Flooring:string;
    Furnishing:string;
    Possesion_ready:boolean;
    water_source:string;
    Address:string;
    Advance:number;
    Ameneties:boolean;
    Carpet_area:number;
    Construction_Age:number;
    no_of_floors:number;
    Posted_date:string;
    Price:number;
    Property_description:string;
    Property_Name:string;
    Type:string;
    Location_name:string;
    City_name:string;
    AvailableFor:string;
    Occupancy: number;
    PropertyId: number;
    isVerified: boolean;
    Name: string;
    Phone_number: number;
    email: string;
    
    Ac:boolean;
    Lift:boolean;
    Gas_conn: boolean;
    Community_hall: boolean;
    Bed: boolean;
    Parking: boolean;
    Refridgerator: boolean;
    Sofa: boolean;
    swimming_pool: boolean;
    Tv: boolean;
  
  }
  export class City
  {
      CityId: number;
      City_name:string;
      
  }
  
  