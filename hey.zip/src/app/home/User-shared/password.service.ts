import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class PasswordService {

  result:number;
  otp:string;
  emailID:string;
  message:string;
  _destUrl ='http://localhost:59207/api/Users/';
  constructor(public http : HttpClient) { }

  verifyEmail(email:string) : Observable<any> 
  {
    return this.http.get(this._destUrl+'verifyMail?mail='+email);
  }
  generateOTP(email:string) : Observable<any> 
  {
    //console.log(m);
    return this.http.get(this._destUrl+'generateOTP?mail='+email);
  }
  updatePassword(password:string)
  {
    this.message=this.emailID+':'+password;
    return this.http.get(this._destUrl+'updatePassword?parameter='+this.message);
    
  }
  confirmPassword(oldPassword:string) : Observable<any> 
  {
    this.message=this.emailID+':'+oldPassword;
    return this.http.get(this._destUrl+'confirmPassword?parameter='+this.message);
  }
}
