import { Injectable } from '@angular/core';
import { User } from "src/app/home/User-shared/UserModel";
import { Property } from "src/app/home/User-shared/Property.Model";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {

  selectedUser = new User();
  apptag = false;
  PropertyList = new Array<Property>();
  constructor(public http : HttpClient) { }

  getUserPropertyById(id : number): Observable<any>
  {
    return this.http.get('http://localhost:59207/api/Users/'+id);
  }
  
  getPropertyList(id:number): Observable<any> {
    return this.http.get('http://localhost:59207/api/Properties/GetUserProperty?id='+ id);
  }

  getUserById(id : number): Observable<any>
  {
    return this.http.get('http://localhost:59207/api/Users/'+id);
  //   this.http.get('http://localhost:54650/api/Users/22').
  //   pipe(map((data:Response)=>{return data.json() as User[];
  //   }).toPromise().then(x=>{this.userList=x;})
  //  }
  }

  putUser(user:User):Observable<any>
  {
    var body=JSON.stringify(user);
    let headerOption :HttpHeaders=new HttpHeaders()
      .set('Content-Type','application/json')
      .set('Access-Control-Allow-Origin','http://localhost:4200')
    return this.http.put('http://localhost:59207/api/Users/PutUser',body,{headers:headerOption});
  }

  postUser(user: User) : Observable<any>
  {
    var body = JSON.stringify(user);
    //console.log(this.selectedUser);
    console.log(body);
    let headerOption : HttpHeaders=new HttpHeaders()
    .set ('Content-Type','application/json')
    .set('Access-Control-Allow-Origin','http://localhost:4200');
    return this.http.post('http://localhost:59207/api/Users/PostUser/',body,{headers:headerOption});
  }

}
