import { Injectable } from '@angular/core';
import { User } from "./UserModel";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { $ } from "protractor/built";

@Injectable({
  providedIn: 'root'
})
export class SignupService {
  selectedUser = new User();
  _sourceUrl ='http://localhost:4200';
  _destUrl ='http://localhost:59207/api/Users/';
  constructor(public http : HttpClient) { }
  postUser(user: User) : Observable<any>
  {
    var body = JSON.stringify(user);
    //console.log(this.selectedUser);
    console.log(body);
    let headerOption : HttpHeaders=new HttpHeaders()
    .set ('Content-Type','application/json')
    .set('Access-Control-Allow-Origin',this._sourceUrl);
    return this.http.post(this._destUrl+'PostUser',body,{headers:headerOption});
   //return this.http.post(${this._destUrl}${'PostUser'},body,{headers:headerOption});
    
  }

  verifyEmail()
  {
    var e=this.selectedUser.email;
    return this.http.get(this._destUrl+'VerifyEmail?email='+e);
  }

  verifyPhone()
  {
    var p=this.selectedUser.Phone_number;
    return this.http.get(this._destUrl+'VerifyPhone?phone='+p);
  }

  checkReferralCode()
  {
    //var c=this.selectedUser.Referral_code;
    return this.http.get(this._destUrl+'CheckRefferalCode/?r_code='+this.selectedUser.Referral_code);
  }
}
