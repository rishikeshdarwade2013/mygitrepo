import { Component, OnInit } from '@angular/core';
import { PasswordService } from "src/app/home/User-shared/password.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-changeotp',
  templateUrl: './changeotp.component.html',
  styleUrls: ['./changeotp.component.css']
})
export class ChangeotpComponent implements OnInit {
  newPasword:string;
  confirmNew:string;
  otpGen:string;
  otpField=false;
  otpError=false;
  fieldDisable=true;
  buttonDisable=true;
  smallValue1=true;
  smallValue2=true;
  updateResult=true;
  result:string;
  constructor(public passwordservice : PasswordService, public router : Router) { }

  ngOnInit() {
  }

  verifyOTP()
  {
      if(this.otpGen==this.passwordservice.otp)
      {
        this.fieldDisable=false;
        this.smallValue1=false;
        this.smallValue2=true;
        this.otpField=true;
        this.otpError=true;
        console.log("done!!");
      }
      else
      {
        this.smallValue1=true;
        this.smallValue2=false;
      }
      
  }

  checkPasswords()
  {
    if(this.newPasword==this.confirmNew)
        this.buttonDisable=false;
  }

  updatePassword()
  {
    if(this.newPasword==this.confirmNew)
      this.passwordservice.updatePassword(this.newPasword).subscribe(data => {
        this.result = data.toString();
        console.log(data);
        if(this.result=='1' || this.result=='0')
          this.updateResult=false;
        else
        {
          this.router.navigateByUrl('/bad-request');
        }
      });
    else
      console.log(" no match");
    
  }

}
