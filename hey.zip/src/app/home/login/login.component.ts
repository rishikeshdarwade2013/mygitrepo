import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BoolData } from 'src/app/home/shared/BoolData.model';
import { BaseService } from 'src/app/home/shared/Base.service';
import { Router } from "@angular/router";
import { PasswordService } from "src/app/home/User-shared/password.service";
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public base: BaseService, private router: Router, public passwordservice : PasswordService,private toastr: ToastrService) { }
  flag: Boolean;
  Pasword: string;
  emailID: string;
  userName: string;
  result:number;
  ngOnInit() {
  }
  resetform(form?: NgForm) {
    if (form != null)
      form.reset();
  }
  OnSubmit(form: NgForm) {
    
    if (form.value.email == "admin@mid.com" && form.value.Password == "admin") 
    {
     console.log(form.value)
     localStorage.setItem('adminToken',"a1213d5687m6778i879n");
      this.router.navigateByUrl('/home');
    }
    else
    {
      var concatStr: string;
      concatStr = form.value.email.concat(":");
      //console.log(form.value.password);
      concatStr = concatStr.concat(form.value.password);
      this.base.validateUser(concatStr);
     
    }
  }


  verifyMail()
  {
    //this.router.navigateByUrl('/home/changeotp');
    // console.log("hello");
    this.passwordservice.verifyEmail(this.emailID).subscribe(data => {
      this.result = data;
      console.log(data);
      if(this.result==1)
        {
          this.passwordservice.emailID=this.emailID;
          this.passwordservice.generateOTP(this.emailID).subscribe(data => {
            this.passwordservice.otp = data;
            console.log(this.passwordservice.otp);
            console.log(data);
          });
          console.log(this.result);
          this.router.navigateByUrl('/home/changeotp'); // to be changed 
        }
    });
    
  }

}
