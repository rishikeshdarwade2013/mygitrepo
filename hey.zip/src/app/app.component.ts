import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css','../assets/css/demo.css']
})
export class AppComponent {
  title = 'FindMyRoomAngular';
}
