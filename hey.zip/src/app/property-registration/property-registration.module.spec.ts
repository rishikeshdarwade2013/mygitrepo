import { PropertyRegistrationModule } from './property-registration.module';

describe('PropertyRegistrationModule', () => {
  let propertyRegistrationModule: PropertyRegistrationModule;

  beforeEach(() => {
    propertyRegistrationModule = new PropertyRegistrationModule();
  });

  it('should create an instance', () => {
    expect(propertyRegistrationModule).toBeTruthy();
  });
});
