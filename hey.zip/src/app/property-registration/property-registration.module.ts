import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PropertyRegistrationRoutingModule } from './property-registration-routing.module';

@NgModule({
  imports: [
    CommonModule,
    PropertyRegistrationRoutingModule
  ],
  declarations: []
})
export class PropertyRegistrationModule { }
