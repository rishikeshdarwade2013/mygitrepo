import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OwnerlistComponent } from "./ownerlist/ownerlist.component";
import { PropertylistComponent } from "./propertylist/propertylist.component";
import { ReadfeedbackComponent } from "./readfeedback/readfeedback.component";
import { UserlistComponent } from "./userlist/userlist.component";
import { VerificationComponent } from "./verification/verification.component";
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from "src/app/app.component";
import { AdminHomeComponent } from "./admin-home.component";
import { AdminHomeIndexComponent } from "src/app/admin/admin-home-index/admin-home-index.component";


const adminroutes: Routes = [
  {
    path: '', component: AdminHomeComponent,
    children: [
      { path: 'index', component: AdminHomeIndexComponent },
      { path: 'ownerlist', component: OwnerlistComponent },
      { path: 'propertylist', component: PropertylistComponent },
      { path: 'readfeedbck', component: ReadfeedbackComponent },
      { path: 'userlist', component: UserlistComponent },
      { path: 'verification', component: VerificationComponent }
    ]
  },

];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(adminroutes)
  ],
  declarations: [],
  exports: [RouterModule]

})

export class AdminRoutingModule { }
