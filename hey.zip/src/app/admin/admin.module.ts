import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from "./admin-routing.module";
import { PropertylistComponent } from './propertylist/propertylist.component';
import { OwnerlistComponent } from './ownerlist/ownerlist.component';
import { UserlistComponent } from './userlist/userlist.component';
import { VerificationComponent } from './verification/verification.component';
import { ReadfeedbackComponent } from './readfeedback/readfeedback.component';
import { AdminHomeComponent } from './admin-home.component';
import { RouterModule } from "@angular/router";
import { AdminserviceService } from "./shared/adminservice.service";
import { HttpClientModule } from "@angular/common/http";
import { AdminHomeIndexComponent } from './admin-home-index/admin-home-index.component';


@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule,
    HttpClientModule
  ],
  declarations: [
    AdminHomeComponent,
    PropertylistComponent,
    ReadfeedbackComponent,
    OwnerlistComponent,
    UserlistComponent,
    VerificationComponent,
    AdminHomeIndexComponent
  ]
})
export class AdminModule { }
