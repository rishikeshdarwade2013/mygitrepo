import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from "../shared/adminservice.service";
import { Users, Owners, Properties } from "../shared/admin.model";
@Component({
  selector: 'app-propertylist',
  templateUrl: './propertylist.component.html',
  styleUrls: ['./propertylist.component.css']
})
export class PropertylistComponent implements OnInit {
   property = new Properties();
  constructor(public adminservice : AdminserviceService) { }

  ngOnInit() {
    
  }

}
