import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from "../shared/adminservice.service";
import { Users, Owners } from "../shared/admin.model";

@Component({
  selector: 'app-ownerlist',
  templateUrl: './ownerlist.component.html',
  styleUrls: ['./ownerlist.component.css']
})
export class OwnerlistComponent implements OnInit {

  constructor(public adminservice : AdminserviceService) { }

  ngOnInit() {
    this.adminservice.get_owners().subscribe(data => {
      this.adminservice.owners = data as Owners[];
      console.log(this.adminservice.owners);
      console.log(data);
    });
  }

}
