import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from "./shared/adminservice.service";

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css'],
  providers : [AdminserviceService]
})
export class AdminHomeComponent implements OnInit {

  constructor(public adminservice : AdminserviceService) { }

  ngOnInit() {
  }

}
