import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from "../shared/adminservice.service";
import { Users, Owners, FeedBackPosts } from "../shared/admin.model";

@Component({
  selector: 'app-readfeedback',
  templateUrl: './readfeedback.component.html',
  styleUrls: ['./readfeedback.component.css']
})
export class ReadfeedbackComponent implements OnInit {

  constructor(public adminservice :AdminserviceService) { }

  ngOnInit() {
    this.adminservice.get_feedbacks().subscribe( data => {
      this.adminservice.feedbacks = data;
      console.log(this.adminservice.feedbacks);
    })
  }

  deletefeedback(feedbacks : FeedBackPosts){
    this.adminservice.delete_feedback(feedbacks).subscribe( (data : Response) => {
      console.log(data);
      this.adminservice.get_feedbacks().subscribe( data => 
      this.adminservice.feedbacks = data as FeedBackPosts[] );
    } );
  }


}
