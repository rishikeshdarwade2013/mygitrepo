import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-home-index',
  templateUrl: './admin-home-index.component.html',
  styleUrls: ['./admin-home-index.component.css']
})
export class AdminHomeIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
