import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from "../shared/adminservice.service";
import { Users, Owners } from "../shared/admin.model";

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {

  constructor(public adminservice :AdminserviceService) { }

  ngOnInit() {
    this.adminservice.get_users().subscribe(data => {
      this.adminservice.users = data as Users[];
      console.log(this.adminservice.users);
    });
  }

}
