import { AdminHomeIndexComponent } from 'src/app/admin/admin-home-index/admin-home-index.component';
import { LoginAuthenticationService } from './home/shared/login-authentication.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeModule} from './home/home.module'
import {HomeIndexComponent} from './home/home-index/home-index.component'
import { AdminModule } from "./admin/admin.module";
import { LoginComponent } from 'src/app/home/login/login.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { LoginAuthenticationGuard } from "src/app/home/shared/login-authentication.guard";
import { Router } from "@angular/router";
import {HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import {HttpModule,Http,Response,Headers,RequestOptions,RequestMethod} from '@angular/http';
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { ToastrModule } from 'ngx-toastr';

@NgModule({
  
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,ToastrModule.forRoot(),
    FormsModule,HttpModule,HttpClientModule, ReactiveFormsModule, BrowserAnimationsModule
   
  ],
  providers: [LoginAuthenticationService,LoginAuthenticationGuard],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private router:Router) {}
}
 
