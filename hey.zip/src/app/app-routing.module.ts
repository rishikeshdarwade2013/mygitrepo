import { AdminHomeIndexComponent } from './admin/admin-home-index/admin-home-index.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from "./app.component";
import { AdminModule } from "src/app/admin/admin.module";
import { HomeModule } from "src/app/home/home.module";
import { LoginComponent } from "src/app/home/login/login.component";
import { LoginAuthenticationGuard } from "src/app/home/shared/login-authentication.guard";
import { LoginAuthenticationService } from 'src/app/home/shared/login-authentication.service';
import { AdminAuthGuard } from "src/app/home/shared/admin-auth.guard";

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'admin', loadChildren: 'src/app/admin/admin.module#AdminModule'},
  { path: 'home', loadChildren: () => HomeModule },
  //{path:'User',component:UserComponent},
  
];
// 

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
