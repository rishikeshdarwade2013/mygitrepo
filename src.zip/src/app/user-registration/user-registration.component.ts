import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import {ToastrService} from 'ngx-toastr';
import { UserService } from "src/app/shared/user.service";
import { User } from "src/app/shared/user.model";

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css'],
  providers: [UserService]
  
})
export class UserRegistrationComponent implements OnInit {
result: string;
mailCheck=true;
phoneCheck=true;
formValid=true;
rcode=true;
  constructor(public userService : UserService, private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();

  }
  resetForm(form?: NgForm)
  {
    if(form != null)
      {
        form.reset();
        this.userService.selectedUser = new User();
      }
  }

  onSubmit(form : NgForm)
      {
        console.log(this.userService.selectedUser);
        this.userService.postUser(this.userService.selectedUser)
        .subscribe(data=>{
          this.resetForm(form);
          this.toastr.success('New Record added successfully','User Registration');
        },
      err=>{
          console.log("Error in inserting data");
      }
    )}

    checkRefferalCode()
    {
      this.userService.checkReferralCode().subscribe(
        data => {
          this.result=data.toString();
          console.log("Referral code: "+this.result);
          if(this.result=="0")
            {
              this.rcode=false;
            }
          if(this.result=="1") this.rcode=true;
    });
    }

    checkEmail()
    {
      this.userService.verifyEmail().subscribe(
        data => {
          this.result=data.toString();
          console.log("hai"+this.result);
          if(this.result=='1')
            {
                this.mailCheck=false;
                this.formValid=true;
            }
            else{
              this.mailCheck=true;
              this.formValid=false;
            }
        });        
    }

    checkPhone()
    {
      this.userService.verifyPhone().subscribe(
        data => {
          this.result=data.toString();
          console.log("hai"+this.result);
          if(this.result=='1')
            {
                this.phoneCheck=false;
                this.formValid=true;
            }
            else{
              this.formValid=false;
              this.phoneCheck=true;
            }
        });
    }
}
