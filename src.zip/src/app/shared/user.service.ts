import { Injectable } from '@angular/core';
import { User } from "src/app/shared/user.model";
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { HttpHeaders } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
  export class UserService {
    selectedUser= new User();
    constructor(private http: HttpClient) { }
    postUser(user: User) : Observable<any>
    {
      var body = JSON.stringify(user);
      //console.log(this.selectedUser);
      console.log(body);
      let headerOption : HttpHeaders=new HttpHeaders()
      .set ('Content-Type','application/json')
      .set('Access-Control-Allow-Origin','http://localhost:4200');
      return this.http.post('http://localhost:59207/api/Users/PostUser/',body,{headers:headerOption});
    }
    verifyEmail()
    {
      var e=this.selectedUser.email;
      return this.http.get('http://localhost:59207/api/Users/VerifyEmail?email='+e);
    }
    verifyPhone()
    {
      var p=this.selectedUser.Phone_number;
      return this.http.get('http://localhost:59207/api/Users/VerifyPhone?phone='+p);
    }
    checkReferralCode()
    {
      var c=this.selectedUser.Referral_code;
      return this.http.get('http://localhost:59207/api/Users/CheckRefferalCode/?r_code='+c);
    }
  }