export class User
{
    public UserId: number
    public Name: string
    public email: string
    public Phone_number: string
    public password: string
    public Referral_code :string;
}